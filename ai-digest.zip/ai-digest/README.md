# AI Digest

Własny, przefiltrowany feed RSS z newsami AI, nowymi modelami, narzędziami i repozytoriami.
Działa na darmowym GitHub Actions, publikuje na GitHub Pages, czytasz w Inoreaderze na Androidzie.

Bez API keys. Bez LLM. Bez kosztów.

## Co zbiera

| Kategoria | Źródło | Filtrowanie |
|---|---|---|
| 🚀 RELEASE | Nowe wersje 16 obserwowanych repo (Claude Code, LangGraph, Unsloth, OpenOA…) | brak — wszystko przechodzi |
| 📰 NEWS | Blogi Anthropic, OpenAI, DeepMind, HF, Simon Willison, Mistral | brak — kurowane źródła |
| 📰 NEWS | r/LocalLLaMA, Hacker News | po słowach kluczowych |
| 📦 REPO | GitHub Trending + nowe repo z Search API (≥40 ⭐, <14 dni) | po słowach kluczowych |
| 📄 PAPER | HF Daily Papers, arXiv cs.CL, cs.CV | po słowach kluczowych |

## Setup (10 minut)

### 1. Repo
Nowe **publiczne** repo `ai-digest` (publiczne = darmowe Actions i Pages), wrzuć te pliki.

### 2. Włącz Pages
`Settings → Pages → Build and deployment → Source: GitHub Actions`

### 3. Uprawnienia Actions
`Settings → Actions → General → Workflow permissions` → **Read and write permissions** → Save

### 4. Ustaw swój URL
W `config.yaml` zmień:
```yaml
site_url: "https://TWOJ-USERNAME.github.io/ai-digest"
```

### 5. Pierwsze uruchomienie
`Actions → AI Digest → Run workflow`

Po ~2 min feed żyje pod:
- Podgląd: `https://TWOJ-USERNAME.github.io/ai-digest/`
- **RSS: `https://TWOJ-USERNAME.github.io/ai-digest/feed.xml`** ← to wklejasz do Inoreadera

### 6. Inoreader
Dodaj subskrypcję → wklej URL feed.xml. Gotowe.

## Strojenie

Wszystko w `config.yaml`, kod zostaje nietknięty. Push do `main` = natychmiastowy rebuild.

**Za dużo szumu?**
- `github_search.min_stars: 40` → podnieś do 100
- Usuń `arXiv cs.CV` (generuje najwięcej pozycji)
- Dopisz śmieciowe frazy do `keywords.exclude`

**Za mało?**
- Obniż `min_stars`
- Dodaj słowa do `keywords.include`
- Przełącz źródło na `tier: always`

**Nowe repo do obserwowania:** dopisz `owner/repo` do `github_releases`.

**Częstotliwość:** zmień `cron` w `.github/workflows/digest.yml`. Raz dziennie: usuń drugą linię crona.

## Jak to działa

`digest.py` → pobiera feedy + GitHub API → filtruje po słowach kluczowych → dedup względem `state.json` → generuje `docs/feed.xml` (Atom) i `docs/index.html` → commit + deploy na Pages.

`state.json` trzyma UID-y widzianych pozycji, więc nic nie pojawia się dwa razy.
Feed zachowuje ostatnie 120 pozycji.

## Koszt

0 zł. Publiczne repo = nielimitowane Actions. Pages = darmowe.
GitHub API bez tokenu: 60 req/h. W Actions token jest wstrzykiwany automatycznie → 5000 req/h.
